﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demo
{
    public partial class issue_books : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\arron\Documents\Studies\KCIC\Semester 3\Unit 30 - Application Development\Assignment\My Assignment\LMS\library_management.mdf;Integrated Security=True;Connect Timeout=30");

        public issue_books()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int i = 0;
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = " select * from Student_info where student_enrollment_no = '" + txt_enroll.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());
                if (i == 0)
                {
                    MessageBox.Show("Enrollment Number not found");
                }
                else
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        txt_student_name.Text = dr["student_name"].ToString();
                        txt_department.Text = dr["student_department"].ToString();
                        txt_sem.Text = dr["student_sem"].ToString();
                        txt_contact.Text = dr["student_contact"].ToString();
                        txt_email.Text = dr["student_email"].ToString();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void issue_books_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        private void txt_book_name_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                int count = 0;
                if (e.KeyCode != Keys.Enter)
                {
                    listBox1.Items.Clear();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = " select * from Books_info where books_name like('%" + txt_book_name.Text + "%')";
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    count = Convert.ToInt32(dt.Rows.Count.ToString());
                    if (count > 0)
                    {
                        listBox1.Visible = true;
                        foreach (DataRow dr in dt.Rows)
                        {
                            listBox1.Items.Add(dr["books_name"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void txt_book_name_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Down)
                {
                    listBox1.Focus();
                    listBox1.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    txt_book_name.Text = listBox1.SelectedItem.ToString();
                    listBox1.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                txt_book_name.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int books_qty = 0;
                SqlCommand cmd2 = con.CreateCommand();
                cmd2.CommandType = CommandType.Text;
                cmd2.CommandText = " select * from Books_info where books_name like('%" + txt_book_name.Text + "%')";
                cmd2.ExecuteNonQuery();
                DataTable dt2 = new DataTable();
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                da2.Fill(dt2);
                foreach (DataRow dr2 in dt2.Rows)
                {
                    books_qty = Convert.ToInt32(dr2["books_available_quantity"].ToString());
                }

                if (books_qty > 0)
                {

                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into Issue_books values('" + txt_enroll.Text + "','" + txt_student_name.Text + "','" + txt_department.Text + "','" + txt_sem.Text + "','" + txt_contact.Text + "','" + txt_email.Text + "','" + txt_book_name.Text + "','" + dateTimePicker1.Value.ToString() + "','')";
                    cmd.ExecuteNonQuery();

                    SqlCommand cmd1 = con.CreateCommand();
                    cmd1.CommandType = CommandType.Text;
                    cmd1.CommandText = "update Books_info set books_available_quantity= books_available_quantity-1 where books_name = '" + txt_book_name.Text + "'";
                    cmd1.ExecuteNonQuery();
                    MessageBox.Show("Book Issued successfully");
                }
                else
                {
                    MessageBox.Show("Book not found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
